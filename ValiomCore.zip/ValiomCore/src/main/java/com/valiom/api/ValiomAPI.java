package com.valiom.api;

import com.valiom.api.managers.ProfileManager;

public interface ValiomAPI {

    ProfileManager getProfileManager();
}
